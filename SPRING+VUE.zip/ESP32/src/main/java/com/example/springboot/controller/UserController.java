package com.example.springboot.controller;
import com.example.springboot.entity.User;
import com.example.springboot.mapper.Usermapper;
import com.example.springboot.service.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;



@RestController
@RequestMapping("/user")
public class UserController {
    @Autowired
    private Usermapper usermapper;


    @Autowired
    private Userservice userservice;

    @PostMapping   //插入或者修改数据
    public Integer save(@RequestBody User user) {
        //新增或者更新
        return userservice.save(user);
    }

    // 查询所有数据
    @GetMapping()
    public List<User> index() {
        List<User> all= usermapper.findAll();
        return all;
    }

    //删除
    @DeleteMapping("/{id}")
    public Integer delete(@PathVariable Integer id){
       return usermapper.deleteById(id);
    }

    //接口路径/user/page?pageNum=1&pageSize=10
    //分页查询
    @GetMapping("/page")
    public Map<String,Object> findPage(@RequestParam Integer pageNum,@RequestParam Integer pageSize) {
        pageNum=(pageNum-1)*pageSize;
        List<User> data = usermapper.selectPage(pageNum, pageSize);
        Integer total = usermapper.selectTotal();
        Map<String,Object> res = new HashMap<>();
        res.put("data",data);
        res.put("total",total);
        return res;
    }
}
