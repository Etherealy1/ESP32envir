package com.example.springboot.service;


import com.example.springboot.entity.User;
import com.example.springboot.mapper.Usermapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Userservice {

    @Autowired
    private Usermapper usermapper;

    public int save(User user) {
        if(user.getId() == null){     //user没有ID为新增
          return   usermapper.insert(user);
        }else{  //更新
           return usermapper.update(user);
        }
    }
}

